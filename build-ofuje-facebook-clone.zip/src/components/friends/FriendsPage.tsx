/**
 * Friends Page Component
 * Display friend list, friend requests, and suggestions
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import {
  collection,
  query,
  where,
  onSnapshot,
  addDoc,
  deleteDoc,
  doc,
  updateDoc,
  arrayUnion,
  getDocs,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../../firebase/config';
import { FriendRequest, User } from '../../types';
import {
  UserPlus,
  UserMinus,
  Check,
  X,
  MessageCircle,
  Search,
  Users,
  UserCheck,
  Clock,
  Loader2
} from 'lucide-react';

const FriendsPage: React.FC = () => {
  const { currentUser, userData } = useAuth();
  const { isDarkMode } = useTheme();
  const [activeTab, setActiveTab] = useState<'friends' | 'requests' | 'suggestions'>('friends');
  const [friends, setFriends] = useState<User[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [suggestions, setSuggestions] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch friends
  useEffect(() => {
    if (!userData?.friends?.length) {
      setFriends([]);
      setLoading(false);
      return;
    }

    const fetchFriends = async () => {
      const friendsData: User[] = [];
      for (const friendId of userData.friends) {
        const q = query(collection(db, 'users'), where('__name__', '==', friendId));
        const snapshot = await getDocs(q);
        snapshot.forEach(doc => {
          friendsData.push({ id: doc.id, ...doc.data() } as User);
        });
      }
      setFriends(friendsData);
      setLoading(false);
    };

    fetchFriends();
  }, [userData?.friends]);

  // Fetch friend requests
  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, 'friendRequests'),
      where('receiverId', '==', currentUser.uid),
      where('status', '==', 'pending')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const requestsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as FriendRequest[];
      setRequests(requestsData);
    });

    return unsubscribe;
  }, [currentUser]);

  // Fetch suggestions
  useEffect(() => {
    const fetchSuggestions = async () => {
      const q = query(collection(db, 'users'));
      const snapshot = await getDocs(q);
      const usersData: User[] = [];
      
      snapshot.forEach(doc => {
        const user = { id: doc.id, ...doc.data() } as User;
        // Don't suggest current user or existing friends
        if (user.id !== currentUser?.uid && !userData?.friends?.includes(user.id)) {
          usersData.push(user);
        }
      });
      
      setSuggestions(usersData.slice(0, 10));
    };

    fetchSuggestions();
  }, [currentUser, userData?.friends]);

  // Send friend request
  const sendFriendRequest = async (user: User) => {
    if (!currentUser || !userData) return;

    await addDoc(collection(db, 'friendRequests'), {
      senderId: currentUser.uid,
      senderName: userData.displayName,
      senderPhoto: userData.photoURL,
      receiverId: user.id,
      status: 'pending',
      createdAt: serverTimestamp()
    });

    // Send notification
    await addDoc(collection(db, 'notifications'), {
      userId: user.id,
      type: 'friend_request',
      fromUserId: currentUser.uid,
      fromUserName: userData.displayName,
      fromUserPhoto: userData.photoURL,
      message: `${userData.displayName} sent you a friend request`,
      read: false,
      createdAt: serverTimestamp()
    });

    setSuggestions(prev => prev.filter(u => u.id !== user.id));
  };

  // Accept friend request
  const acceptRequest = async (request: FriendRequest) => {
    if (!currentUser) return;

    // Update request status
    await updateDoc(doc(db, 'friendRequests', request.id), {
      status: 'accepted'
    });

    // Add to both users' friends lists
    await updateDoc(doc(db, 'users', currentUser.uid), {
      friends: arrayUnion(request.senderId)
    });
    await updateDoc(doc(db, 'users', request.senderId), {
      friends: arrayUnion(currentUser.uid)
    });

    // Send notification
    await addDoc(collection(db, 'notifications'), {
      userId: request.senderId,
      type: 'friend_accept',
      fromUserId: currentUser.uid,
      fromUserName: userData?.displayName,
      fromUserPhoto: userData?.photoURL,
      message: `${userData?.displayName} accepted your friend request`,
      read: false,
      createdAt: serverTimestamp()
    });
  };

  // Reject friend request
  const rejectRequest = async (request: FriendRequest) => {
    await deleteDoc(doc(db, 'friendRequests', request.id));
  };

  // Remove friend
  const removeFriend = async (friendId: string) => {
    if (!currentUser || !window.confirm('Remove this friend?')) return;

    // Remove from both users' friends lists
    const currentFriends = userData?.friends?.filter(id => id !== friendId) || [];
    await updateDoc(doc(db, 'users', currentUser.uid), {
      friends: currentFriends
    });

    const friendDoc = friends.find(f => f.id === friendId);
    if (friendDoc) {
      const theirFriends = friendDoc.friends?.filter(id => id !== currentUser.uid) || [];
      await updateDoc(doc(db, 'users', friendId), {
        friends: theirFriends
      });
    }

    setFriends(prev => prev.filter(f => f.id !== friendId));
  };

  const tabs = [
    { id: 'friends', label: 'Friends', icon: Users, count: friends.length },
    { id: 'requests', label: 'Requests', icon: Clock, count: requests.length },
    { id: 'suggestions', label: 'Suggestions', icon: UserPlus, count: suggestions.length },
  ];

  const filteredFriends = friends.filter(f =>
    f.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`${isDarkMode ? 'bg-gray-800/50' : 'bg-white'} rounded-2xl border ${isDarkMode ? 'border-white/10' : 'border-gray-200'} overflow-hidden`}>
      {/* Header */}
      <div className="p-6 border-b border-white/10">
        <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
          Friends
        </h1>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search friends..."
            className={`w-full pl-12 pr-4 py-3 ${isDarkMode ? 'bg-white/5 border-white/10 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-200 text-gray-900 placeholder-gray-500'} border rounded-xl focus:outline-none focus:ring-2 focus:ring-violet-500`}
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mt-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white'
                  : isDarkMode
                    ? 'bg-white/5 text-gray-400 hover:text-white'
                    : 'bg-gray-100 text-gray-600 hover:text-gray-900'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
              {tab.count > 0 && (
                <span className={`px-2 py-0.5 text-xs rounded-full ${
                  activeTab === tab.id
                    ? 'bg-white/20'
                    : 'bg-violet-500/20 text-violet-400'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 text-violet-500 animate-spin" />
          </div>
        ) : (
          <>
            {/* Friends List */}
            {activeTab === 'friends' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredFriends.length === 0 ? (
                  <div className="col-span-2 text-center py-12">
                    <Users className={`h-16 w-16 mx-auto mb-4 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`} />
                    <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                      {searchQuery ? 'No friends found' : 'No friends yet'}
                    </p>
                  </div>
                ) : (
                  filteredFriends.map((friend) => (
                    <div
                      key={friend.id}
                      className={`flex items-center gap-4 p-4 rounded-xl ${isDarkMode ? 'bg-white/5 hover:bg-white/10' : 'bg-gray-50 hover:bg-gray-100'} transition-colors`}
                    >
                      <div className="relative">
                        <img
                          src={friend.photoURL}
                          alt={friend.displayName}
                          className="h-14 w-14 rounded-full object-cover"
                        />
                        <div className={`absolute bottom-0 right-0 h-4 w-4 rounded-full border-2 ${isDarkMode ? 'border-gray-800' : 'border-white'} ${friend.isOnline ? 'bg-emerald-500' : 'bg-gray-400'}`} />
                      </div>
                      <div className="flex-1">
                        <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          {friend.displayName}
                        </h3>
                        <p className="text-gray-400 text-sm">
                          {friend.isOnline ? 'Online' : 'Offline'}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <button className="p-2 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white hover:shadow-lg transition-all">
                          <MessageCircle className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => removeFriend(friend.id)}
                          className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all"
                        >
                          <UserMinus className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Friend Requests */}
            {activeTab === 'requests' && (
              <div className="space-y-4">
                {requests.length === 0 ? (
                  <div className="text-center py-12">
                    <UserCheck className={`h-16 w-16 mx-auto mb-4 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`} />
                    <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                      No pending friend requests
                    </p>
                  </div>
                ) : (
                  requests.map((request) => (
                    <div
                      key={request.id}
                      className={`flex items-center gap-4 p-4 rounded-xl ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'}`}
                    >
                      <img
                        src={request.senderPhoto}
                        alt={request.senderName}
                        className="h-14 w-14 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          {request.senderName}
                        </h3>
                        <p className="text-gray-400 text-sm">
                          Sent you a friend request
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => acceptRequest(request)}
                          className="px-4 py-2 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-medium hover:shadow-lg transition-all flex items-center gap-2"
                        >
                          <Check className="h-4 w-4" />
                          Accept
                        </button>
                        <button
                          onClick={() => rejectRequest(request)}
                          className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Suggestions */}
            {activeTab === 'suggestions' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {suggestions.length === 0 ? (
                  <div className="col-span-3 text-center py-12">
                    <UserPlus className={`h-16 w-16 mx-auto mb-4 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`} />
                    <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                      No suggestions available
                    </p>
                  </div>
                ) : (
                  suggestions.map((user) => (
                    <div
                      key={user.id}
                      className={`p-4 rounded-xl ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'} text-center`}
                    >
                      <img
                        src={user.photoURL}
                        alt={user.displayName}
                        className="h-20 w-20 rounded-full object-cover mx-auto mb-3"
                      />
                      <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        {user.displayName}
                      </h3>
                      <p className="text-gray-400 text-sm mb-4">
                        {user.bio || 'Ofuje Member'}
                      </p>
                      <button
                        onClick={() => sendFriendRequest(user)}
                        className="w-full py-2 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2"
                      >
                        <UserPlus className="h-4 w-4" />
                        Add Friend
                      </button>
                    </div>
                  ))
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default FriendsPage;
