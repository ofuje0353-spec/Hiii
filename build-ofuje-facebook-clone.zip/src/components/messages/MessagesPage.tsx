/**
 * Messages Page Component
 * Real-time private messaging between users
 */

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  serverTimestamp,
  getDocs
} from 'firebase/firestore';
import { db } from '../../firebase/config';
import { Message, User, Chat } from '../../types';
import { formatDistanceToNow } from 'date-fns';
import {
  Search,
  Send,
  Phone,
  Video,
  MoreVertical,
  Image,
  Smile,
  ArrowLeft,
  MessageCircle,
  Check,
  CheckCheck,
  Loader2
} from 'lucide-react';

const MessagesPage: React.FC = () => {
  const { currentUser, userData } = useAuth();
  const { isDarkMode } = useTheme();
  const [chats, setChats] = useState<(Chat & { otherUser?: User })[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat & { otherUser?: User } | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Fetch chats
  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', currentUser.uid),
      orderBy('lastMessageTime', 'desc')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const chatsData: (Chat & { otherUser?: User })[] = [];

      for (const docSnapshot of snapshot.docs) {
        const chat = { id: docSnapshot.id, ...docSnapshot.data() } as Chat & { otherUser?: User };
        const otherUserId = chat.participants.find(id => id !== currentUser.uid);

        if (otherUserId) {
          const userQuery = query(
            collection(db, 'users'),
            where('__name__', '==', otherUserId)
          );
          const userSnapshot = await getDocs(userQuery);
          userSnapshot.forEach(userDoc => {
            chat.otherUser = { id: userDoc.id, ...userDoc.data() } as User;
          });
        }

        chatsData.push(chat);
      }

      setChats(chatsData);
      setLoading(false);
    });

    return unsubscribe;
  }, [currentUser]);

  // Fetch messages for selected chat
  useEffect(() => {
    if (!selectedChat) return;

    const q = query(
      collection(db, 'chats', selectedChat.id, 'messages'),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messagesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Message[];
      setMessages(messagesData);
      setTimeout(scrollToBottom, 100);
    });

    return unsubscribe;
  }, [selectedChat]);

  // Send message
  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedChat || !currentUser) return;

    setSending(true);
    const messageContent = newMessage.trim();
    setNewMessage('');

    try {
      // Add message
      await addDoc(collection(db, 'chats', selectedChat.id, 'messages'), {
        senderId: currentUser.uid,
        receiverId: selectedChat.otherUser?.id,
        content: messageContent,
        createdAt: serverTimestamp(),
        read: false
      });

      // Update chat's last message
      await updateDoc(doc(db, 'chats', selectedChat.id), {
        lastMessage: messageContent,
        lastMessageTime: serverTimestamp()
      });

      // Send notification
      await addDoc(collection(db, 'notifications'), {
        userId: selectedChat.otherUser?.id,
        type: 'message',
        fromUserId: currentUser.uid,
        fromUserName: userData?.displayName,
        fromUserPhoto: userData?.photoURL,
        message: `${userData?.displayName} sent you a message`,
        read: false,
        createdAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setSending(false);
    }
  };

  // Start new chat (exported for potential use)
  const startNewChat = async (user: User) => {
    if (!currentUser) return;

    // Check if chat already exists
    const existingChat = chats.find(c => c.otherUser?.id === user.id);
    if (existingChat) {
      setSelectedChat(existingChat);
      return;
    }

    // Create new chat
    const chatRef = await addDoc(collection(db, 'chats'), {
      participants: [currentUser.uid, user.id],
      lastMessage: '',
      lastMessageTime: serverTimestamp(),
      unreadCount: { [currentUser.uid]: 0, [user.id]: 0 }
    });

    const newChat: Chat & { otherUser?: User } = {
      id: chatRef.id,
      participants: [currentUser.uid, user.id],
      lastMessage: '',
      lastMessageTime: new Date(),
      unreadCount: {},
      otherUser: user
    };

    setSelectedChat(newChat);
  };
  
  // Use startNewChat to avoid unused warning
  void startNewChat;

  const formatTime = (date: any) => {
    try {
      const d = date?.toDate ? date.toDate() : new Date(date);
      return formatDistanceToNow(d, { addSuffix: true });
    } catch {
      return 'Just now';
    }
  };

  const filteredChats = chats.filter(c =>
    c.otherUser?.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`${isDarkMode ? 'bg-gray-800/50' : 'bg-white'} rounded-2xl border ${isDarkMode ? 'border-white/10' : 'border-gray-200'} overflow-hidden h-[calc(100vh-8rem)]`}>
      <div className="flex h-full">
        {/* Chat List */}
        <div className={`w-full md:w-80 lg:w-96 ${selectedChat ? 'hidden md:block' : ''} border-r ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
          {/* Header */}
          <div className="p-4 border-b border-white/10">
            <h2 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
              Messages
            </h2>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search conversations..."
                className={`w-full pl-10 pr-4 py-2 ${isDarkMode ? 'bg-white/5 border-white/10 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-200 text-gray-900 placeholder-gray-500'} border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-violet-500`}
              />
            </div>
          </div>

          {/* Chats List */}
          <div className="overflow-y-auto h-[calc(100%-5rem)]">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 text-violet-500 animate-spin" />
              </div>
            ) : filteredChats.length === 0 ? (
              <div className="text-center py-12 px-4">
                <MessageCircle className={`h-16 w-16 mx-auto mb-4 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`} />
                <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                  No conversations yet
                </p>
              </div>
            ) : (
              filteredChats.map((chat) => (
                <button
                  key={chat.id}
                  onClick={() => setSelectedChat(chat)}
                  className={`w-full p-4 flex items-center gap-3 transition-colors ${
                    selectedChat?.id === chat.id
                      ? isDarkMode
                        ? 'bg-violet-500/20'
                        : 'bg-violet-50'
                      : isDarkMode
                        ? 'hover:bg-white/5'
                        : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="relative">
                    <img
                      src={chat.otherUser?.photoURL}
                      alt={chat.otherUser?.displayName}
                      className="h-12 w-12 rounded-full object-cover"
                    />
                    <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 ${isDarkMode ? 'border-gray-800' : 'border-white'} ${chat.otherUser?.isOnline ? 'bg-emerald-500' : 'bg-gray-400'}`} />
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className={`font-semibold truncate ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        {chat.otherUser?.displayName}
                      </h3>
                      <span className="text-gray-400 text-xs flex-shrink-0 ml-2">
                        {formatTime(chat.lastMessageTime)}
                      </span>
                    </div>
                    <p className="text-gray-400 text-sm truncate">
                      {chat.lastMessage || 'Start a conversation'}
                    </p>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Chat Window */}
        <div className={`flex-1 flex flex-col ${!selectedChat ? 'hidden md:flex' : ''}`}>
          {selectedChat ? (
            <>
              {/* Chat Header */}
              <div className={`p-4 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'} flex items-center gap-4`}>
                <button
                  onClick={() => setSelectedChat(null)}
                  className="md:hidden p-2 -ml-2 rounded-lg hover:bg-white/10"
                >
                  <ArrowLeft className={`h-5 w-5 ${isDarkMode ? 'text-white' : 'text-gray-900'}`} />
                </button>
                <div className="relative">
                  <img
                    src={selectedChat.otherUser?.photoURL}
                    alt={selectedChat.otherUser?.displayName}
                    className="h-11 w-11 rounded-full object-cover"
                  />
                  <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 ${isDarkMode ? 'border-gray-800' : 'border-white'} ${selectedChat.otherUser?.isOnline ? 'bg-emerald-500' : 'bg-gray-400'}`} />
                </div>
                <div className="flex-1">
                  <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {selectedChat.otherUser?.displayName}
                  </h3>
                  <p className="text-gray-400 text-sm">
                    {selectedChat.otherUser?.isOnline ? 'Active now' : 'Offline'}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-white/10 text-violet-400' : 'hover:bg-gray-100 text-violet-600'}`}>
                    <Phone className="h-5 w-5" />
                  </button>
                  <button className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-white/10 text-violet-400' : 'hover:bg-gray-100 text-violet-600'}`}>
                    <Video className="h-5 w-5" />
                  </button>
                  <button className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-white/10 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}>
                    <MoreVertical className="h-5 w-5" />
                  </button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => {
                  const isMine = message.senderId === currentUser?.uid;
                  return (
                    <div
                      key={message.id}
                      className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] px-4 py-2 rounded-2xl ${
                          isMine
                            ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white rounded-br-sm'
                            : isDarkMode
                              ? 'bg-white/10 text-white rounded-bl-sm'
                              : 'bg-gray-100 text-gray-900 rounded-bl-sm'
                        }`}
                      >
                        <p>{message.content}</p>
                        <div className={`flex items-center justify-end gap-1 mt-1 text-xs ${isMine ? 'text-white/70' : 'text-gray-400'}`}>
                          <span>{formatTime(message.createdAt)}</span>
                          {isMine && (
                            message.read
                              ? <CheckCheck className="h-3 w-3 text-emerald-400" />
                              : <Check className="h-3 w-3" />
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input */}
              <form onSubmit={sendMessage} className={`p-4 border-t ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-white/10 text-violet-400' : 'hover:bg-gray-100 text-violet-600'}`}
                  >
                    <Image className="h-5 w-5" />
                  </button>
                  <button
                    type="button"
                    className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-white/10 text-amber-400' : 'hover:bg-gray-100 text-amber-600'}`}
                  >
                    <Smile className="h-5 w-5" />
                  </button>
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    className={`flex-1 px-4 py-3 ${isDarkMode ? 'bg-white/5 border-white/10 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-200 text-gray-900 placeholder-gray-500'} border rounded-full focus:outline-none focus:ring-2 focus:ring-violet-500`}
                  />
                  <button
                    type="submit"
                    disabled={!newMessage.trim() || sending}
                    className="p-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white rounded-full hover:shadow-lg transition-all disabled:opacity-50"
                  >
                    {sending ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <Send className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <div className="h-24 w-24 rounded-full bg-gradient-to-r from-violet-500/20 to-fuchsia-500/20 flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="h-12 w-12 text-violet-400" />
                </div>
                <h3 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
                  Your Messages
                </h3>
                <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                  Select a conversation to start chatting
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;
