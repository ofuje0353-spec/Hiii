/**
 * Notifications Page Component
 * Display all user notifications with real-time updates
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  doc,
  deleteDoc,
  writeBatch
} from 'firebase/firestore';
import { db } from '../../firebase/config';
import { Notification } from '../../types';
import { formatDistanceToNow } from 'date-fns';
import {
  Bell,
  Heart,
  MessageCircle,
  UserPlus,
  UserCheck,
  Check,
  Trash2,
  Loader2,
  BellOff
} from 'lucide-react';

const NotificationsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { isDarkMode } = useTheme();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  // Fetch notifications
  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', currentUser.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notificationsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Notification[];
      setNotifications(notificationsData);
      setLoading(false);
    });

    return unsubscribe;
  }, [currentUser]);

  // Mark as read
  const markAsRead = async (notification: Notification) => {
    if (notification.read) return;
    await updateDoc(doc(db, 'notifications', notification.id), {
      read: true
    });
  };

  // Mark all as read
  const markAllAsRead = async () => {
    const batch = writeBatch(db);
    notifications
      .filter(n => !n.read)
      .forEach(n => {
        batch.update(doc(db, 'notifications', n.id), { read: true });
      });
    await batch.commit();
  };

  // Delete notification
  const deleteNotification = async (id: string) => {
    await deleteDoc(doc(db, 'notifications', id));
  };

  // Clear all notifications
  const clearAll = async () => {
    if (!window.confirm('Clear all notifications?')) return;
    const batch = writeBatch(db);
    notifications.forEach(n => {
      batch.delete(doc(db, 'notifications', n.id));
    });
    await batch.commit();
  };

  // Get icon based on notification type
  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="h-5 w-5 text-pink-500 fill-pink-500" />;
      case 'comment':
        return <MessageCircle className="h-5 w-5 text-blue-500" />;
      case 'friend_request':
        return <UserPlus className="h-5 w-5 text-violet-500" />;
      case 'friend_accept':
        return <UserCheck className="h-5 w-5 text-emerald-500" />;
      case 'message':
        return <MessageCircle className="h-5 w-5 text-fuchsia-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-400" />;
    }
  };

  // Get gradient based on notification type
  const getGradient = (type: Notification['type']) => {
    switch (type) {
      case 'like':
        return 'from-pink-500/20 to-red-500/20';
      case 'comment':
        return 'from-blue-500/20 to-cyan-500/20';
      case 'friend_request':
        return 'from-violet-500/20 to-purple-500/20';
      case 'friend_accept':
        return 'from-emerald-500/20 to-teal-500/20';
      case 'message':
        return 'from-fuchsia-500/20 to-pink-500/20';
      default:
        return 'from-gray-500/20 to-gray-500/20';
    }
  };

  const formatTime = (date: any) => {
    try {
      const d = date?.toDate ? date.toDate() : new Date(date);
      return formatDistanceToNow(d, { addSuffix: true });
    } catch {
      return 'Just now';
    }
  };

  const filteredNotifications = filter === 'unread'
    ? notifications.filter(n => !n.read)
    : notifications;

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className={`${isDarkMode ? 'bg-gray-800/50' : 'bg-white'} rounded-2xl border ${isDarkMode ? 'border-white/10' : 'border-gray-200'} overflow-hidden`}>
      {/* Header */}
      <div className={`p-6 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-r from-violet-500/20 to-fuchsia-500/20">
              <Bell className="h-6 w-6 text-violet-400" />
            </div>
            <div>
              <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Notifications
              </h1>
              {unreadCount > 0 && (
                <p className="text-gray-400 text-sm">
                  {unreadCount} unread notification{unreadCount > 1 ? 's' : ''}
                </p>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="px-4 py-2 text-violet-400 hover:bg-violet-500/10 rounded-xl transition-colors flex items-center gap-2"
              >
                <Check className="h-4 w-4" />
                <span className="hidden sm:inline">Mark all read</span>
              </button>
            )}
            {notifications.length > 0 && (
              <button
                onClick={clearAll}
                className="px-4 py-2 text-red-400 hover:bg-red-500/10 rounded-xl transition-colors flex items-center gap-2"
              >
                <Trash2 className="h-4 w-4" />
                <span className="hidden sm:inline">Clear all</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-xl font-medium transition-all ${
              filter === 'all'
                ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white'
                : isDarkMode
                  ? 'bg-white/5 text-gray-400 hover:text-white'
                  : 'bg-gray-100 text-gray-600 hover:text-gray-900'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('unread')}
            className={`px-4 py-2 rounded-xl font-medium transition-all flex items-center gap-2 ${
              filter === 'unread'
                ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white'
                : isDarkMode
                  ? 'bg-white/5 text-gray-400 hover:text-white'
                  : 'bg-gray-100 text-gray-600 hover:text-gray-900'
            }`}
          >
            Unread
            {unreadCount > 0 && (
              <span className={`px-2 py-0.5 text-xs rounded-full ${
                filter === 'unread'
                  ? 'bg-white/20'
                  : 'bg-violet-500/20 text-violet-400'
              }`}>
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="max-h-[calc(100vh-16rem)] overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 text-violet-500 animate-spin" />
          </div>
        ) : filteredNotifications.length === 0 ? (
          <div className="text-center py-12 px-4">
            <BellOff className={`h-16 w-16 mx-auto mb-4 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`} />
            <h3 className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
              {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
            </h3>
            <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
              {filter === 'unread'
                ? 'You\'re all caught up!'
                : 'When you get notifications, they\'ll show up here'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            {filteredNotifications.map((notification) => (
              <div
                key={notification.id}
                onClick={() => markAsRead(notification)}
                className={`p-4 flex items-start gap-4 cursor-pointer transition-colors ${
                  notification.read
                    ? isDarkMode
                      ? 'hover:bg-white/5'
                      : 'hover:bg-gray-50'
                    : `bg-gradient-to-r ${getGradient(notification.type)} hover:opacity-80`
                }`}
              >
                {/* User Photo */}
                <div className="relative flex-shrink-0">
                  <img
                    src={notification.fromUserPhoto}
                    alt={notification.fromUserName}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-gray-900">
                    {getIcon(notification.type)}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <p className={isDarkMode ? 'text-white' : 'text-gray-900'}>
                    <span className="font-semibold">{notification.fromUserName}</span>{' '}
                    <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>
                      {notification.message.replace(notification.fromUserName, '')}
                    </span>
                  </p>
                  <p className="text-gray-400 text-sm mt-1">
                    {formatTime(notification.createdAt)}
                  </p>
                </div>

                {/* Actions */}
                <div className="flex-shrink-0 flex items-center gap-2">
                  {!notification.read && (
                    <div className="h-3 w-3 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 animate-pulse" />
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteNotification(notification.id);
                    }}
                    className={`p-2 rounded-lg ${isDarkMode ? 'hover:bg-white/10' : 'hover:bg-gray-100'} text-gray-400 hover:text-red-400 transition-colors`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;
