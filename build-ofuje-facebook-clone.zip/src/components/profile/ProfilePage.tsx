/**
 * Profile Page Component
 * Display and edit user profile
 */

import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../firebase/config';
import { Post as PostType } from '../../types';
import Post from '../feed/Post';
import {
  Camera,
  Edit2,
  MapPin,
  Link as LinkIcon,
  Calendar,
  Mail,
  Users,
  Image as ImageIcon,
  Heart,
  MessageCircle,
  X,
  Loader2,
  Save
} from 'lucide-react';

interface Props {
  userId?: string;
}

const ProfilePage: React.FC<Props> = ({ userId }) => {
  const { currentUser, userData, updateUserData } = useAuth();
  const { isDarkMode } = useTheme();
  const [posts, setPosts] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    displayName: userData?.displayName || '',
    bio: userData?.bio || '',
    location: userData?.location || '',
    website: userData?.website || '',
    birthday: userData?.birthday || ''
  });
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [saving, setSaving] = useState(false);

  const photoInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  const profileUserId = userId || currentUser?.uid;
  const isOwnProfile = !userId || userId === currentUser?.uid;

  // Fetch user's posts
  useEffect(() => {
    if (!profileUserId) return;

    const q = query(
      collection(db, 'posts'),
      where('authorId', '==', profileUserId),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const postsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as PostType[];
      setPosts(postsData);
      setLoading(false);
    });

    return unsubscribe;
  }, [profileUserId]);

  // Update edit data when userData changes
  useEffect(() => {
    if (userData) {
      setEditData({
        displayName: userData.displayName || '',
        bio: userData.bio || '',
        location: userData.location || '',
        website: userData.website || '',
        birthday: userData.birthday || ''
      });
    }
  }, [userData]);

  // Handle photo upload
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    setUploadingPhoto(true);
    try {
      const photoRef = ref(storage, `users/${currentUser.uid}/profile_${Date.now()}`);
      await uploadBytes(photoRef, file);
      const photoURL = await getDownloadURL(photoRef);
      await updateUserData({ photoURL });
    } catch (error) {
      console.error('Error uploading photo:', error);
    } finally {
      setUploadingPhoto(false);
    }
  };

  // Handle cover upload
  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    setUploadingCover(true);
    try {
      const coverRef = ref(storage, `users/${currentUser.uid}/cover_${Date.now()}`);
      await uploadBytes(coverRef, file);
      const coverURL = await getDownloadURL(coverRef);
      await updateUserData({ coverURL });
    } catch (error) {
      console.error('Error uploading cover:', error);
    } finally {
      setUploadingCover(false);
    }
  };

  // Save profile changes
  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      await updateUserData(editData);
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving profile:', error);
    } finally {
      setSaving(false);
    }
  };

  const stats = [
    { label: 'Posts', value: posts.length, icon: ImageIcon },
    { label: 'Friends', value: userData?.friends?.length || 0, icon: Users },
    { label: 'Likes', value: posts.reduce((acc, p) => acc + p.likes.length, 0), icon: Heart },
  ];

  return (
    <div className="space-y-6">
      {/* Cover & Profile Section */}
      <div className={`${isDarkMode ? 'bg-gray-800/50' : 'bg-white'} rounded-2xl border ${isDarkMode ? 'border-white/10' : 'border-gray-200'} overflow-hidden`}>
        {/* Cover Photo */}
        <div className="relative h-48 sm:h-64 md:h-80">
          <img
            src={userData?.coverURL || 'https://images.unsplash.com/photo-1557683316-973673baf926?w=1200&h=400&fit=crop'}
            alt="Cover"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          
          {/* Cover Upload Button */}
          {isOwnProfile && (
            <>
              <input
                ref={coverInputRef}
                type="file"
                accept="image/*"
                onChange={handleCoverUpload}
                className="hidden"
              />
              <button
                onClick={() => coverInputRef.current?.click()}
                disabled={uploadingCover}
                className="absolute bottom-4 right-4 px-4 py-2 bg-black/50 hover:bg-black/70 text-white rounded-lg backdrop-blur-sm transition-colors flex items-center gap-2"
              >
                {uploadingCover ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Camera className="h-4 w-4" />
                )}
                Edit Cover
              </button>
            </>
          )}
        </div>

        {/* Profile Info */}
        <div className="px-6 pb-6 -mt-16 relative">
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-4">
            {/* Profile Photo */}
            <div className="relative">
              <img
                src={userData?.photoURL}
                alt={userData?.displayName}
                className="h-32 w-32 rounded-full object-cover border-4 border-gray-900 shadow-xl"
              />
              {isOwnProfile && (
                <>
                  <input
                    ref={photoInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                  <button
                    onClick={() => photoInputRef.current?.click()}
                    disabled={uploadingPhoto}
                    className="absolute bottom-2 right-2 p-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all"
                  >
                    {uploadingPhoto ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Camera className="h-4 w-4" />
                    )}
                  </button>
                </>
              )}
            </div>

            {/* Name & Stats */}
            <div className="flex-1 text-center sm:text-left">
              <h1 className={`text-2xl sm:text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                {userData?.displayName}
              </h1>
              {userData?.bio && (
                <p className={`mt-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {userData.bio}
                </p>
              )}
              
              {/* Quick Stats */}
              <div className="flex flex-wrap justify-center sm:justify-start gap-4 mt-4">
                {stats.map((stat) => (
                  <div key={stat.label} className="flex items-center gap-2">
                    <stat.icon className="h-4 w-4 text-violet-400" />
                    <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {stat.value}
                    </span>
                    <span className="text-gray-400">{stat.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            {isOwnProfile ? (
              <button
                onClick={() => setIsEditing(true)}
                className="px-6 py-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-semibold rounded-xl hover:shadow-lg transition-all flex items-center gap-2"
              >
                <Edit2 className="h-4 w-4" />
                Edit Profile
              </button>
            ) : (
              <div className="flex gap-2">
                <button className="px-6 py-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-semibold rounded-xl hover:shadow-lg transition-all flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Add Friend
                </button>
                <button className={`px-6 py-2 ${isDarkMode ? 'bg-white/10' : 'bg-gray-100'} ${isDarkMode ? 'text-white' : 'text-gray-900'} font-semibold rounded-xl hover:shadow-lg transition-all flex items-center gap-2`}>
                  <MessageCircle className="h-4 w-4" />
                  Message
                </button>
              </div>
            )}
          </div>

          {/* Details */}
          <div className={`mt-6 pt-6 border-t ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
            <div className="flex flex-wrap gap-6">
              {userData?.location && (
                <div className="flex items-center gap-2 text-gray-400">
                  <MapPin className="h-4 w-4" />
                  {userData.location}
                </div>
              )}
              {userData?.website && (
                <a href={userData.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-violet-400 hover:underline">
                  <LinkIcon className="h-4 w-4" />
                  {userData.website}
                </a>
              )}
              {userData?.birthday && (
                <div className="flex items-center gap-2 text-gray-400">
                  <Calendar className="h-4 w-4" />
                  {userData.birthday}
                </div>
              )}
              <div className="flex items-center gap-2 text-gray-400">
                <Mail className="h-4 w-4" />
                {userData?.email}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className={`w-full max-w-lg ${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-2xl`}>
            {/* Header */}
            <div className={`flex items-center justify-between p-4 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
              <h2 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Edit Profile
              </h2>
              <button
                onClick={() => setIsEditing(false)}
                className="p-2 rounded-full hover:bg-white/10 transition-colors"
              >
                <X className={`h-5 w-5 ${isDarkMode ? 'text-white' : 'text-gray-900'}`} />
              </button>
            </div>

            {/* Form */}
            <div className="p-4 space-y-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Display Name
                </label>
                <input
                  type="text"
                  value={editData.displayName}
                  onChange={(e) => setEditData({ ...editData, displayName: e.target.value })}
                  className={`w-full px-4 py-3 rounded-xl ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-100 border-gray-200 text-gray-900'} border focus:outline-none focus:ring-2 focus:ring-violet-500`}
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Bio
                </label>
                <textarea
                  value={editData.bio}
                  onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                  rows={3}
                  className={`w-full px-4 py-3 rounded-xl ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-100 border-gray-200 text-gray-900'} border focus:outline-none focus:ring-2 focus:ring-violet-500 resize-none`}
                  placeholder="Tell us about yourself..."
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Location
                </label>
                <input
                  type="text"
                  value={editData.location}
                  onChange={(e) => setEditData({ ...editData, location: e.target.value })}
                  className={`w-full px-4 py-3 rounded-xl ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-100 border-gray-200 text-gray-900'} border focus:outline-none focus:ring-2 focus:ring-violet-500`}
                  placeholder="Where are you from?"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Website
                </label>
                <input
                  type="url"
                  value={editData.website}
                  onChange={(e) => setEditData({ ...editData, website: e.target.value })}
                  className={`w-full px-4 py-3 rounded-xl ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-100 border-gray-200 text-gray-900'} border focus:outline-none focus:ring-2 focus:ring-violet-500`}
                  placeholder="https://yourwebsite.com"
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Birthday
                </label>
                <input
                  type="date"
                  value={editData.birthday}
                  onChange={(e) => setEditData({ ...editData, birthday: e.target.value })}
                  className={`w-full px-4 py-3 rounded-xl ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-100 border-gray-200 text-gray-900'} border focus:outline-none focus:ring-2 focus:ring-violet-500`}
                />
              </div>
            </div>

            {/* Footer */}
            <div className={`flex justify-end gap-3 p-4 border-t ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
              <button
                onClick={() => setIsEditing(false)}
                className={`px-6 py-2 ${isDarkMode ? 'bg-white/10 text-white' : 'bg-gray-100 text-gray-900'} rounded-xl font-medium transition-colors`}
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProfile}
                disabled={saving}
                className="px-6 py-2 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {saving ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* User's Posts */}
      <div>
        <h2 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
          Posts
        </h2>
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 text-violet-500 animate-spin" />
          </div>
        ) : posts.length === 0 ? (
          <div className={`text-center py-12 ${isDarkMode ? 'bg-gray-800/50' : 'bg-white'} rounded-2xl border ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
            <ImageIcon className={`h-16 w-16 mx-auto mb-4 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`} />
            <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
              No posts yet
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {posts.map((post) => (
              <Post key={post.id} post={post} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;
