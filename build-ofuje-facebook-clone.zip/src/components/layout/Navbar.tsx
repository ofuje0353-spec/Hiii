/**
 * Navbar Component
 * Main navigation bar with search, notifications, and user menu
 */

import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import {
  Home,
  Users,
  MessageCircle,
  Bell,
  Search,
  Menu,
  X,
  Sun,
  Moon,
  LogOut,
  Settings,
  User
} from 'lucide-react';

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  notifications: number;
  messages: number;
  onSearch: (query: string) => void;
}

const Navbar: React.FC<Props> = ({ activeTab, setActiveTab, notifications, messages, onSearch }) => {
  const { userData, logout } = useAuth();
  const { isDarkMode, toggleTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const navItems = [
    { id: 'feed', icon: Home, label: 'Home' },
    { id: 'friends', icon: Users, label: 'Friends' },
    { id: 'messages', icon: MessageCircle, label: 'Messages', badge: messages },
    { id: 'notifications', icon: Bell, label: 'Notifications', badge: notifications },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 ${isDarkMode ? 'bg-gray-900/95' : 'bg-white/95'} backdrop-blur-xl border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-extrabold bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 bg-clip-text text-transparent cursor-pointer" onClick={() => setActiveTab('feed')}>
              Ofuje
            </h1>

            {/* Search Bar - Desktop */}
            <form onSubmit={handleSearch} className="hidden md:block relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Ofuje..."
                className={`w-64 pl-10 pr-4 py-2 ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-100 border-gray-200 text-gray-900'} border rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 transition-all`}
              />
            </form>
          </div>

          {/* Navigation - Desktop */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative p-3 rounded-xl transition-all duration-300 ${
                  activeTab === item.id
                    ? 'bg-gradient-to-r from-violet-500/20 to-fuchsia-500/20 text-violet-400'
                    : isDarkMode ? 'text-gray-400 hover:bg-white/5 hover:text-white' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <item.icon className="h-6 w-6" />
                {item.badge && item.badge > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-gradient-to-r from-pink-500 to-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center animate-bounce">
                    {item.badge > 9 ? '9+' : item.badge}
                  </span>
                )}
                {activeTab === item.id && (
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-1 bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-3">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-full ${isDarkMode ? 'bg-white/5 text-yellow-400 hover:bg-white/10' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'} transition-all`}
            >
              {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>

            {/* User Menu */}
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 p-1 rounded-full hover:ring-2 hover:ring-violet-500/50 transition-all"
              >
                <img
                  src={userData?.photoURL}
                  alt={userData?.displayName}
                  className="h-9 w-9 rounded-full object-cover border-2 border-violet-500"
                />
              </button>

              {/* Dropdown Menu */}
              {showUserMenu && (
                <div className={`absolute right-0 mt-2 w-64 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-2xl border ${isDarkMode ? 'border-white/10' : 'border-gray-200'} overflow-hidden animate-fadeIn`}>
                  {/* User Info */}
                  <div className={`p-4 ${isDarkMode ? 'border-white/10' : 'border-gray-200'} border-b`}>
                    <div className="flex items-center gap-3">
                      <img
                        src={userData?.photoURL}
                        alt={userData?.displayName}
                        className="h-12 w-12 rounded-full object-cover"
                      />
                      <div>
                        <p className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{userData?.displayName}</p>
                        <p className="text-gray-400 text-sm">{userData?.email}</p>
                      </div>
                    </div>
                  </div>

                  {/* Menu Items */}
                  <div className="p-2">
                    <button
                      onClick={() => { setActiveTab('profile'); setShowUserMenu(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl ${isDarkMode ? 'text-white hover:bg-white/5' : 'text-gray-900 hover:bg-gray-100'} transition-colors`}
                    >
                      <User className="h-5 w-5 text-violet-400" />
                      View Profile
                    </button>
                    <button
                      onClick={() => { setActiveTab('settings'); setShowUserMenu(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl ${isDarkMode ? 'text-white hover:bg-white/5' : 'text-gray-900 hover:bg-gray-100'} transition-colors`}
                    >
                      <Settings className="h-5 w-5 text-violet-400" />
                      Settings
                    </button>
                    <button
                      onClick={logout}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-colors"
                    >
                      <LogOut className="h-5 w-5" />
                      Log Out
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className={`md:hidden p-2 rounded-full ${isDarkMode ? 'bg-white/5 text-white' : 'bg-gray-100 text-gray-600'}`}
            >
              {showMobileMenu ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {showMobileMenu && (
          <div className={`md:hidden py-4 ${isDarkMode ? 'border-white/10' : 'border-gray-200'} border-t animate-slideDown`}>
            {/* Mobile Search */}
            <form onSubmit={handleSearch} className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Ofuje..."
                className={`w-full pl-10 pr-4 py-3 ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-100 border-gray-200 text-gray-900'} border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-violet-500`}
              />
            </form>

            {/* Mobile Nav Items */}
            <div className="space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setShowMobileMenu(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-violet-500/20 to-fuchsia-500/20 text-violet-400'
                      : isDarkMode ? 'text-white hover:bg-white/5' : 'text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  {item.label}
                  {item.badge && item.badge > 0 && (
                    <span className="ml-auto px-2 py-0.5 bg-gradient-to-r from-pink-500 to-red-500 text-white text-xs font-bold rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
