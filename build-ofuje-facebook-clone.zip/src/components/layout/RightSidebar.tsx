/**
 * Right Sidebar Component
 * Shows online friends and sponsored content
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { User } from '../../types';
import { Search, MessageCircle, Users, Gift, Calendar, Star } from 'lucide-react';

const RightSidebar: React.FC = () => {
  const { userData } = useAuth();
  const { isDarkMode } = useTheme();
  const [friends, setFriends] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch friends
  useEffect(() => {
    if (!userData?.friends?.length) {
      setFriends([]);
      return;
    }

    const fetchFriends = async () => {
      const friendsData: User[] = [];
      for (const friendId of userData.friends) {
        const q = query(collection(db, 'users'), where('__name__', '==', friendId));
        const snapshot = await getDocs(q);
        snapshot.forEach(doc => {
          friendsData.push({ id: doc.id, ...doc.data() } as User);
        });
      }
      setFriends(friendsData);
    };

    fetchFriends();
  }, [userData?.friends]);

  const onlineFriends = friends.filter(f => f.isOnline);
  const filteredFriends = searchQuery
    ? friends.filter(f => f.displayName.toLowerCase().includes(searchQuery.toLowerCase()))
    : friends;

  return (
    <aside className={`hidden xl:block fixed right-0 top-16 bottom-0 w-80 ${isDarkMode ? 'bg-gray-900/50' : 'bg-white/50'} backdrop-blur-xl border-l ${isDarkMode ? 'border-white/10' : 'border-gray-200'} overflow-y-auto`}>
      <div className="p-4 space-y-6">
        {/* Sponsored */}
        <div>
          <h3 className={`text-sm font-semibold ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mb-3`}>
            Sponsored
          </h3>
          <div className={`p-3 rounded-xl ${isDarkMode ? 'bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10' : 'bg-gradient-to-br from-violet-50 to-fuchsia-50'} border ${isDarkMode ? 'border-white/10' : 'border-violet-200'} cursor-pointer hover:scale-[1.02] transition-transform`}>
            <img
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=300&h=150&fit=crop"
              alt="Sponsored"
              className="w-full h-24 object-cover rounded-lg mb-2"
            />
            <p className={`font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Learn Web Development
            </p>
            <p className="text-gray-400 text-sm">codecourse.com</p>
          </div>
        </div>

        {/* Birthdays */}
        <div className={`p-4 rounded-xl ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'}`}>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-gradient-to-r from-pink-500/20 to-red-500/20">
              <Gift className="h-5 w-5 text-pink-500" />
            </div>
            <div>
              <p className={`font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Birthdays
              </p>
              <p className="text-gray-400 text-sm">No birthdays today</p>
            </div>
          </div>
        </div>

        {/* Events */}
        <div className={`p-4 rounded-xl ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'}`}>
          <div className="flex items-center gap-3 mb-3">
            <Calendar className="h-5 w-5 text-amber-500" />
            <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Upcoming Events
            </span>
          </div>
          <div className="space-y-2">
            <div className={`p-3 rounded-lg ${isDarkMode ? 'bg-white/5' : 'bg-white'} flex items-center gap-3`}>
              <div className="h-10 w-10 rounded-lg bg-gradient-to-r from-violet-500 to-fuchsia-500 flex items-center justify-center">
                <Star className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className={`font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'} text-sm`}>
                  Ofuje Launch Party
                </p>
                <p className="text-gray-400 text-xs">Tomorrow at 8 PM</p>
              </div>
            </div>
          </div>
        </div>

        {/* Contacts */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className={`text-sm font-semibold ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Contacts
            </h3>
            <div className="flex items-center gap-2">
              {onlineFriends.length > 0 && (
                <span className="text-emerald-400 text-xs flex items-center gap-1">
                  <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                  {onlineFriends.length} online
                </span>
              )}
            </div>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search contacts..."
              className={`w-full pl-9 pr-4 py-2 ${isDarkMode ? 'bg-white/5 border-white/10 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-200 text-gray-900 placeholder-gray-500'} border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-violet-500`}
            />
          </div>

          {/* Friends List */}
          <div className="space-y-1">
            {friends.length === 0 ? (
              <div className="text-center py-6">
                <Users className={`h-10 w-10 mx-auto mb-2 ${isDarkMode ? 'text-gray-600' : 'text-gray-400'}`} />
                <p className="text-gray-400 text-sm">No contacts yet</p>
              </div>
            ) : filteredFriends.length === 0 ? (
              <p className="text-gray-400 text-sm text-center py-4">
                No contacts found
              </p>
            ) : (
              filteredFriends.map((friend) => (
                <button
                  key={friend.id}
                  className={`w-full flex items-center gap-3 p-2 rounded-lg ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-gray-100'} transition-colors group`}
                >
                  <div className="relative">
                    <img
                      src={friend.photoURL}
                      alt={friend.displayName}
                      className="h-9 w-9 rounded-full object-cover"
                    />
                    <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 ${isDarkMode ? 'border-gray-900' : 'border-white'} ${friend.isOnline ? 'bg-emerald-500' : 'bg-gray-400'}`} />
                  </div>
                  <span className={`flex-1 text-left font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {friend.displayName}
                  </span>
                  <MessageCircle className={`h-4 w-4 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity`} />
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </aside>
  );
};

export default RightSidebar;
