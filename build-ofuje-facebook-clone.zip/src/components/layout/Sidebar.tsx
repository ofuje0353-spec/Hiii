/**
 * Sidebar Component
 * Left sidebar with navigation and quick access
 */

import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import {
  Home,
  Users,
  MessageCircle,
  Bell,
  Bookmark,
  Calendar,
  Settings,
  HelpCircle,
  TrendingUp
} from 'lucide-react';

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<Props> = ({ activeTab, setActiveTab }) => {
  const { userData } = useAuth();
  const { isDarkMode } = useTheme();

  const menuItems = [
    { id: 'feed', icon: Home, label: 'News Feed', gradient: 'from-violet-500 to-fuchsia-500' },
    { id: 'friends', icon: Users, label: 'Friends', gradient: 'from-blue-500 to-cyan-500' },
    { id: 'messages', icon: MessageCircle, label: 'Messages', gradient: 'from-emerald-500 to-teal-500' },
    { id: 'notifications', icon: Bell, label: 'Notifications', gradient: 'from-amber-500 to-orange-500' },
    { id: 'saved', icon: Bookmark, label: 'Saved', gradient: 'from-pink-500 to-rose-500' },
    { id: 'events', icon: Calendar, label: 'Events', gradient: 'from-indigo-500 to-purple-500' },
  ];

  const footerItems = [
    { id: 'settings', icon: Settings, label: 'Settings' },
    { id: 'help', icon: HelpCircle, label: 'Help & Support' },
  ];

  return (
    <aside className={`hidden lg:block fixed left-0 top-16 bottom-0 w-72 ${isDarkMode ? 'bg-gray-900/50' : 'bg-white/50'} backdrop-blur-xl border-r ${isDarkMode ? 'border-white/10' : 'border-gray-200'} overflow-y-auto`}>
      <div className="p-4 space-y-6">
        {/* User Profile Card */}
        <button
          onClick={() => setActiveTab('profile')}
          className={`w-full p-4 rounded-2xl ${isDarkMode ? 'bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 hover:from-violet-500/20 hover:to-fuchsia-500/20' : 'bg-gradient-to-br from-violet-50 to-fuchsia-50 hover:from-violet-100 hover:to-fuchsia-100'} border ${isDarkMode ? 'border-white/10' : 'border-violet-200'} transition-all duration-300 group`}
        >
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={userData?.photoURL}
                alt={userData?.displayName}
                className="h-14 w-14 rounded-xl object-cover ring-2 ring-violet-500/50 group-hover:ring-violet-500 transition-all"
              />
              <div className="absolute -bottom-1 -right-1 h-4 w-4 bg-emerald-500 rounded-full border-2 border-gray-900" />
            </div>
            <div className="text-left">
              <p className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'} group-hover:text-violet-400 transition-colors`}>
                {userData?.displayName}
              </p>
              <p className="text-gray-400 text-sm">View your profile</p>
            </div>
          </div>
        </button>

        {/* Main Menu */}
        <nav className="space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                activeTab === item.id
                  ? `bg-gradient-to-r ${item.gradient} text-white shadow-lg`
                  : isDarkMode
                    ? 'text-gray-300 hover:bg-white/5 hover:text-white'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
              }`}
            >
              <div className={`p-2 rounded-lg ${activeTab === item.id ? 'bg-white/20' : `bg-gradient-to-r ${item.gradient} bg-opacity-10`}`}>
                <item.icon className={`h-5 w-5 ${activeTab === item.id ? 'text-white' : 'text-white'}`} />
              </div>
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Trending Section */}
        <div className={`p-4 rounded-2xl ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'}`}>
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="h-5 w-5 text-pink-500" />
            <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Trending</h3>
          </div>
          <div className="space-y-3">
            {['#TechNews', '#Photography', '#Music', '#Travel'].map((tag) => (
              <button
                key={tag}
                className={`block w-full text-left px-3 py-2 rounded-lg ${isDarkMode ? 'hover:bg-white/5 text-gray-400 hover:text-white' : 'hover:bg-gray-100 text-gray-600 hover:text-gray-900'} transition-colors`}
              >
                <span className="bg-gradient-to-r from-violet-500 to-fuchsia-500 bg-clip-text text-transparent font-medium">{tag}</span>
                <p className="text-xs text-gray-500">{Math.floor(Math.random() * 10000)} posts</p>
              </button>
            ))}
          </div>
        </div>

        {/* Footer Menu */}
        <div className="space-y-1">
          {footerItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-all ${isDarkMode ? 'text-gray-400 hover:text-white hover:bg-white/5' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'}`}
            >
              <item.icon className="h-4 w-4" />
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-white/10">
          <p className="text-gray-500 text-xs text-center">
            © 2024 Ofuje • Privacy • Terms
          </p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
