/**
 * Type definitions for Ofuje
 */

export interface User {
  id: string;
  email: string;
  displayName: string;
  photoURL: string;
  coverURL: string;
  bio: string;
  location: string;
  website: string;
  birthday: string;
  isOnline: boolean;
  lastSeen: Date;
  friends: string[];
  createdAt: Date;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  content: string;
  imageURL?: string;
  videoURL?: string;
  likes: string[];
  comments: Comment[];
  shares: number;
  createdAt: Date;
  updatedAt?: Date;
}

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  content: string;
  createdAt: Date;
}

export interface FriendRequest {
  id: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  receiverId: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: Date;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  createdAt: Date;
  read: boolean;
}

export interface Chat {
  id: string;
  participants: string[];
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: { [userId: string]: number };
}

export interface Notification {
  id: string;
  userId: string;
  type: 'like' | 'comment' | 'friend_request' | 'friend_accept' | 'message';
  fromUserId: string;
  fromUserName: string;
  fromUserPhoto: string;
  postId?: string;
  message: string;
  read: boolean;
  createdAt: Date;
}
