/**
 * Firebase Configuration for Ofuje
 * 
 * SETUP INSTRUCTIONS:
 * 1. Go to https://console.firebase.google.com/
 * 2. Create a new project named "Ofuje"
 * 3. Enable Authentication (Email/Password)
 * 4. Enable Firestore Database
 * 5. Enable Storage
 * 6. Copy your config values below
 * 7. Set up Firestore rules (see firestore.rules below)
 */

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Replace with your Firebase config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;

/**
 * FIRESTORE RULES (paste in Firebase Console > Firestore > Rules):
 * 
 * rules_version = '2';
 * service cloud.firestore {
 *   match /databases/{database}/documents {
 *     match /users/{userId} {
 *       allow read: if request.auth != null;
 *       allow write: if request.auth.uid == userId;
 *     }
 *     match /posts/{postId} {
 *       allow read: if request.auth != null;
 *       allow create: if request.auth != null;
 *       allow update, delete: if request.auth.uid == resource.data.authorId;
 *     }
 *     match /friendRequests/{requestId} {
 *       allow read, write: if request.auth != null;
 *     }
 *     match /chats/{chatId} {
 *       allow read, write: if request.auth != null;
 *     }
 *     match /notifications/{notificationId} {
 *       allow read, write: if request.auth != null;
 *     }
 *   }
 * }
 * 
 * STORAGE RULES:
 * 
 * rules_version = '2';
 * service firebase.storage {
 *   match /b/{bucket}/o {
 *     match /{allPaths=**} {
 *       allow read, write: if request.auth != null;
 *     }
 *   }
 * }
 */
